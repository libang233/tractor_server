#!/usr/bin/python3
import datetime
import pymysql


class sqlHelper(object):
    def  __init__(self,host,port,user,passwd,db,table):
        self.host = host
        self.port = port
        self.user = user
        self.password = passwd
        self.db = db
        self.table = table
        self.connect_state = False
    def connect_mysql(self):
        try:
            self.conn = pymysql.connect(host=self.host,port=self.port,user=self.user,passwd=self.password,db=self.db,charset='utf8')
            self.cursor = self.conn.cursor()
            self.connect_state = True
            print('connect ok')
        except:
            print('connect error')
    def close_mysql(self):
        self.conn.close()
        self.connect_state = False
    def query(self):
        if self.connect_state:
            sql = "select * from "+self.table+";"
            try:
                self.cursor.execute(sql)
                row = self.cursor.fetchone()
                print(row)
            except:
                print("query failed")
    def insert_mysql(self,arg,value):
        if self.connect_state:
            table = self.table
            try:
                self.cursor.execute("INSERT INTO "+table+"(" + arg + ") VALUE(" + value + ");")
                self.conn.commit()
                print('insert ok')
            except:
                print("insert failed")
    def insert_noarg_mysql(self,value):
        if self.connect_state:
            table = self.table
            try:
                self.cursor.execute("INSERT INTO "+table+" VALUE(" + value + ");")
                self.conn.commit()
                print('insert ok')
            except:
                print("insert failed")
    def update_mysql(self,value,key):
        if self.connect_state:
            table = self.table
            try:
                self.cursor.execute("UPDATE "+table+" set "+value+" where "+key+";")
                self.conn.commit()
                print('update ok')
            except:
                self.conn.rollback()
                print("update failed")
    def creat_mysql(self):

        sql = """CREATE TABLE tractor (
        id int auto_increment,
        tractor_id int ,
        year int,
        month SMALLINT ,
        day SMALLINT ,
        hour SMALLINT ,
        minute SMALLINT ,
        second SMALLINT ,
        mus int,
        plateNum  CHAR(20),
        carType CHAR(10),
        serialNum int ,
        driver CHAR(10),
        phone CHAR(20),
        speed int ,
        rotateSpeed int ,
        avgEconomy int, 
        gasMassPercent int ,
        waterTemp int, 
        leftLamp SMALLINT ,
        rightLamp SMALLINT ,
        highBeam SMALLINT ,
        lowBeam SMALLINT ,
        gasLamp SMALLINT,  
        engineHitchLamp SMALLINT  ,
        waterTempLamp SMALLINT ,
        oilLamp SMALLINT ,
        batteryLamp SMALLINT  ,
        parkingLamp SMALLINT ,
        parkingHitchLamp SMALLINT ,
        longitude DOUBLE ,
        latitude DOUBLE,
        altitude DOUBLE ,
        primary key(id,tractor_id,year,month,day,hour,minute,second,mus))default charset=utf8;"""
        try:
            self.cursor.execute(sql)
            print("creat ok")
        except:
            print("creat fail")

test = sqlHelper("localhost",3306,"root","kirito","dash","tractor")
test.connect_mysql()

noarg_value = "null,1124,2019,01,16,16,59,30,7863,\'川A4512\',\'M250-E\',8761238,\'林动\',\'18483655552\',20,3000,75,50,90,1,0,1,0,1,1,1,1,1,1,0,2000,32.6578757370,32.6578757370"

test.insert_noarg_mysql(noarg_value)
test.query()
test.close_mysql()